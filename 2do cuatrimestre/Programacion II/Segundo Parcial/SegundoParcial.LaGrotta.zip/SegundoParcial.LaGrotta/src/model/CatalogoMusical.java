package model;

import repository.CSVSerializable;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class CatalogoMusical<T extends CSVSerializable> implements Serializable{
    
    private static final long serialVersionUID = 1L;
    private List<T> items;

    public CatalogoMusical() {
        this.items = new ArrayList<>();
    }
    
    public void agregar(T item){
        validarItemRepetido(item);
        items.add(item);
    }
    
    public void eliminarPorIndice(int indice){
        validarIndice(indice);
        items.remove(indice);
    }
    
    public void obtenerPorIndice(int indice){
        validarIndice(indice);
        items.get(indice);
    }
    
    public List<T> filtrar(Predicate<T> criterio){
        List<T> filtrada = new ArrayList<>();
        for(T elemento : items){
            if(criterio.test(elemento)){
                filtrada.add(elemento);
            }
        }
        return filtrada;
    }
    
    public void ordenarNatural(){
        Collections.sort((List)items); 
    }
    
    public void ordenarConComparator(Comparator<T> comparador) {
        items.sort(comparador);
        items.forEach(System.out::println); // Falto agragarle esto al parcial, porque no se mostraba ordenada y no se podia modificar el main
    }
    
    public void paraCadaElemento(Consumer<T> accion){
        for(T elemento : items){
            accion.accept(elemento);
        }
    }  
    
    private void validarIndice(int indice){
        if(indice < 0 || indice > items.size()){
            throw new IndexOutOfBoundsException("Indice invalido");
        }
    }
    
    private void validarItemRepetido(T item){
        if (items.contains(item)) {
            throw new IllegalArgumentException("item repetido");
        }
    }
    
    public void guardarEnArchivo(String path) throws IOException {
        try (ObjectOutputStream entrada = new ObjectOutputStream(new FileOutputStream(path))) {
            entrada.writeObject(this);
        }
    }
        
    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException  {
        try (ObjectInputStream salida = new ObjectInputStream(new FileInputStream(path))) {
            CatalogoMusical<T> cargado = (CatalogoMusical<T>) salida.readObject();
            this.items = cargado.items;
        }
    }

    public void guardarEnCSV(String path) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            for (T item : items) {
                bw.write(item.toCSV());
                bw.newLine();
            }
        }
    }

    public void cargarDesdeCSV(String path, Function<String, T> fromCSV) throws IOException {
        items.clear(); // Para q borre lo q haya en el catalogo y cargue lo nuevo
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                items.add(fromCSV.apply(linea));
            }
        } 
    }
}
package Interfaces;

public interface DesprenderAroma {

    void desprenderAroma();
}

package Exceptions;

public class FollajeInvalidoException extends RuntimeException{

    private static final String MESSAGE = "Densidad de follaje invalida";
    
    public FollajeInvalidoException() {
        this(MESSAGE);
    }

    public FollajeInvalidoException(String MESSAGE) {
        super(MESSAGE);
    }
}
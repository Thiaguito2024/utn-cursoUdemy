package Enum;


public enum Clasificacion {
    ATP,
    MAYOR13,
    MAYOR18
}

package Model;

import Interfaces.*;
import Exceptions.FollajeInvalidoException;

public class Arbusto extends JardinBotanico implements Planta, Podable { 

    private static final int DENSIDAD_MINIMA = 1;
    private static final int DENSIDAD_MAXIMA = 10;
    private int densidadFollaje;

    public Arbusto(String nombre, String ubicacion, String clima, int densidadFollaje) {
        super(nombre, ubicacion, clima);
        this.densidadFollaje = densidadFollaje;
        validarAlturaFollaje(densidadFollaje);
    }
    
    private void validarAlturaFollaje(int densidadFollaje) {
        if (densidadFollaje < DENSIDAD_MINIMA) {
            throw new FollajeInvalidoException("El follaje es menor que el minimo");
        } else if (densidadFollaje > DENSIDAD_MAXIMA){
            throw new FollajeInvalidoException("El follaje es mayor que el maximo");
        }
    }

    @Override
    public void podarPlantas() {
        System.out.println("Podando el arbusto: " + getNombre() + " en la ubicacion: " + getUbicacion());
    }
    
    @Override
    public String toString() {
        return super.toString() + "\nDensidad del follaje: " + densidadFollaje;
    }
    
    
}
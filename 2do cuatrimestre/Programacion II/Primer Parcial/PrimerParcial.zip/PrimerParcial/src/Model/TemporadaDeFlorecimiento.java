package Model;

public enum TemporadaDeFlorecimiento {
    
    PRIMAVERA, 
    VERANO,
    OTOÑO,
    INIVIERNO
}

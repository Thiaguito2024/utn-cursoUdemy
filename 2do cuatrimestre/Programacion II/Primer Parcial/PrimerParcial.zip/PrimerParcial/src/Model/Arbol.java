package Model;

import Interfaces.*;
import Exceptions.AlturaInvalidaException;

public class Arbol extends JardinBotanico implements Planta, Podable{

    private static final double ALTURA_MAX = 10; 
    private static final double ALTURA_MIN = 0;
    private double altura;
    
    public Arbol(String nombre, String ubicacion, String clima, double altura) {
        super(nombre, ubicacion, clima);
        this.altura = altura;
        chequearAltura();
    }
    
    private void chequearAltura() {
        if (altura < ALTURA_MIN) {
            throw new AlturaInvalidaException("El arbol es mas bajo que la altura minima");
        } else if (altura > ALTURA_MAX) { 
            throw new AlturaInvalidaException("El arbol es mas alto que la altura maxima");
        }
    }

    @Override
    public void podarPlantas() {
        System.out.println("Podando el arbol: " + getNombre() + " en la ubicacion: " + getUbicacion());
    }
    
    @Override
    public String toString() {
        return super.toString() + "\nAltura: " + altura;
    }
    
    
    
    
}
package Interfaces;
        
        
public interface Podable {
    
    void podarPlantas();
}

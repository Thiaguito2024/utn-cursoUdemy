package Enum;

public enum TemporadaFlorecimiento {
    PRIMAVERA, 
    VERANO, 
    OTOÑO, 
    INVIERNO
}

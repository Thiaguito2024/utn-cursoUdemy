package Interfaces;

public interface Planta {

    void desprenderAroma();
    String getNombre();
    String getUbicacion();
}
package Model;

import Interfaces.Planta;

public class Flor extends JardinBotanico implements Planta {

    private TemporadaDeFlorecimiento tempFlorecimiento;
    
    public Flor(String nombre, String ubicacion, String clima, TemporadaDeFlorecimiento tempFlorecimiento) {
        super(nombre, ubicacion, clima);
        this.tempFlorecimiento = tempFlorecimiento;
    }

    @Override
    public String toString() {
        return super.toString() + "\nTemporada de florecimiento: " + tempFlorecimiento;
    }
    
    public TemporadaDeFlorecimiento getTempFlorecimiento(){
        return tempFlorecimiento;
    }
}

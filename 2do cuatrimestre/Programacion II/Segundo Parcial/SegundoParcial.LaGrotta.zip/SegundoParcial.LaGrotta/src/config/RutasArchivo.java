package config;

import java.nio.file.Path;
import java.nio.file.Paths;

public interface RutasArchivo {
    
    static final String BASE = "src/resources";
    static final String FILE_CSV = "cancion.csv";
    static final String FILE_BIN = "cancion.dat";
    
    public static Path getRutaCSV(){
        return Paths.get(BASE, "cancion.csv");
    }
    
    public static Path getRutaBinario(){
        return Paths.get(BASE, "cancion.dat");
    }
    
    public static String getRutaCSVString(){
        return getRutaCSV().toString();
    }
    
    public static String getRutaBinarioString(){
        return getRutaBinario().toString();
    }   
}
package Interfaces;

public interface Podable {

    void podar();
}

package Enum;

public enum Genero {
    POP, 
    ROCK,
    JAZZ
}

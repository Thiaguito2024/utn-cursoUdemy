package Interfaces;

public interface Transmitible {
    
    void transmitir();
}

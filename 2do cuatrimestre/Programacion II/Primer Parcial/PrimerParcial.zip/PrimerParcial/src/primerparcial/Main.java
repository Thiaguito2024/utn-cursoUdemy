package primerparcial;

import Model.*;

public class Main {
    public static void main(String[] args) {
        
        JardinBotanico jardin = new JardinBotanico("Jardín Central", "Zona Norte", "Tropical");
        
        // Escenaario 1
        Arbol roble = new Arbol("Roble", "Zona Norte", "Tropical", 2);
        // Arbol roble2 = new Arbol("Roble", "Zona Norte", "Tropical", 2); 
        // No se pueden agregar 2 plantas con mismo nombre y ubicacion
        
        // Arbol roble2 = new Arbol("Roble", "Zona Norte", "Tropical", 20); 
        // No se puede agregar porque es muy grande(20)
        
        // Arbol roble2 = new Arbol("Roble", "Zona Norte", "Tropical", -1); 
        // No se puede agregar porque es muy chico(-1)

        jardin.agregarPlanta(roble);
        // jardin.agregarPlanta(roble2); 

        // Escenario 2
        Arbusto arbusto = new Arbusto("Arbusto1", "Zona Sur", "Arido", 6);
        Arbusto arbusto2 = new Arbusto("Arbusto2", "Zona Este", "Arido", 6);
                
        Flor flor = new Flor("Rosa", "Zona Oeste", "Calido", TemporadaDeFlorecimiento.PRIMAVERA);
        Flor flor1 = new Flor("Jazmin", "Zona Sur", "Calido", TemporadaDeFlorecimiento.PRIMAVERA);
        
        
        jardin.agregarPlanta(arbusto);
        jardin.agregarPlanta(arbusto2);
        jardin.agregarPlanta(flor);
        jardin.agregarPlanta(flor1);
        
        jardin.mostrarPlantas();
        
        // Escenario 3
        jardin.podarPlantas();
        
        // Escenario 4
        System.out.print("\n");
        jardin.filtrarPorTemporadaFlorecimiento(TemporadaDeFlorecimiento.PRIMAVERA); 
    }
}
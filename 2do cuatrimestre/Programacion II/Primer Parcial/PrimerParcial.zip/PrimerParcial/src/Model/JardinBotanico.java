package Model;

import Exceptions.PlantaRepetidaException;
import Interfaces.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class JardinBotanico implements Podable{
    
    private String nombre;
    private String ubicacion;
    private String clima;
    private List<Planta> listaPlantas;
    
    public JardinBotanico(String nombre, String ubicacion, String clima) {
        this.clima = clima;
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.listaPlantas = new ArrayList<>();
    }
    
    @Override
    public void podarPlantas() {
        for (Planta planta : listaPlantas) {
            if (planta instanceof Podable) {  
                ((Podable) planta).podarPlantas();
            } else {
                System.out.println("La planta " + planta.getNombre() + " no puede ser podada porque es una flor.");
            }
        }
    }
    
    public void desprenderAroma() {
        for (Planta planta : listaPlantas){
            if (planta instanceof Arbusto) {
                System.out.println("El arbusto " + planta.getNombre() + " no tiene aroma.");
            } else {
                System.out.println("Planta" + getNombre() + " desprendiendo aroma");
            }
        }
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }
    
    public void agregarPlanta(Planta planta) {
        validarPlanta(planta);
        listaPlantas.add(planta);
    }
    
    private void validarPlanta(Planta p) {
        for (Planta plantaExistente : listaPlantas){
            if(plantaExistente.getNombre().equals(p.getNombre()) &&
                    plantaExistente.getUbicacion().equals(p.getUbicacion())) {
                throw new PlantaRepetidaException();
            }
        }
    }
       
    public void mostrarPlantas() {
        if (listaPlantas.isEmpty()) {
            System.out.println("No hay plantas en el jardin.");
        } else {
            for (Planta planta : listaPlantas) {
                System.out.println(planta.toString());
                System.out.print("\n");
            }
        }
    }
    
    public void filtrarPorTemporadaFlorecimiento(TemporadaDeFlorecimiento temporada) {
        for (Planta planta : listaPlantas) {
            if (planta instanceof Flor) {  
                Flor flor = (Flor) planta; 
                if (flor.getTempFlorecimiento() == temporada) {
                    System.out.println("La flor " + flor.getNombre() + " florece en " + temporada);
                } else {
                    System.out.println("Ninguna flor florece en " + temporada);
                }
            }
        }
    }
    
    @Override
    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof Planta p)) {
            return false;
        }
        return nombre.equals(p.getNombre()) && ubicacion.equals(p.getUbicacion());
    }

    @Override
    public int hashCode(){
        return Objects.hash(nombre, ubicacion);
    }

    @Override
    public String toString() {
        return "Plantas En El Jardin: " + "\nNombre: " + nombre + " \nUbicacion: " + ubicacion + 
                " \nClima: " + clima;
    }
}

package segundoparcial;

import java.io.IOException;
import model.*;

public class lagrottaMain {
    public static void main(String[] args) {

        try {
            CatalogoMusical<Cancion> catalogo = new CatalogoMusical<>();

            catalogo.agregar(new Cancion(1, "Bohemian Rhapsody", "Queen", GeneroMusical.ROCK));
            catalogo.agregar(new Cancion(2, "Billie Jean", "Michael Jackson", GeneroMusical.POP));
            catalogo.agregar(new Cancion(3, "Shape of You", "Ed Sheeran", GeneroMusical.POP));
            catalogo.agregar(new Cancion(4, "Take Five", "Dave Brubeck", GeneroMusical.JAZZ));
            catalogo.agregar(new Cancion(5, "Canon in D", "Pachelbel", GeneroMusical.CLASICA));

            System.out.println("Catálogo de canciones:");
            catalogo.paraCadaElemento(System.out::println);

            System.out.println("\nCanciones de género POP:");
            catalogo.filtrar(c -> c.getGenero() == GeneroMusical.POP).forEach(System.out::println);

            System.out.println("\nCanciones cuyo título contiene 'shape':");
            catalogo.filtrar(c -> c.getTitulo().contains("shape")).forEach(System.out::println);

            System.out.println("\nCanciones ordenadas por ID:");
            catalogo.ordenarNatural();// Orden natural, por ejemplo, por ID
            catalogo.paraCadaElemento(System.out::println);
            
            System.out.println("\nCanciones ordenadas por artista:");
            catalogo.ordenarConComparator((c1, c2) -> c1.getArtista().compareTo(c2.getArtista()));
            
            System.out.println("\nCanciones ordenadas por titulo:");
            catalogo.ordenarConComparator((c1, c2) -> c1.getTitulo().compareTo(c2.getTitulo()));
           
            catalogo.guardarEnArchivo("src/resources/canciones.dat");

            CatalogoMusical<Cancion> cargado = new CatalogoMusical<>();
            cargado.cargarDesdeArchivo("src/resources/canciones.dat");

            System.out.println("\nCanciones cargadas desde binario:");
            cargado.paraCadaElemento(System.out::println);

            catalogo.guardarEnCSV("src/resources/canciones.csv");

            cargado.cargarDesdeCSV("src/resources/canciones.csv", Cancion::fromCSV);

            System.out.println("\nCanciones cargadas desde CSV:");
            cargado.paraCadaElemento(System.out::println);

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    
    
    }
}
package Interfaces;


public interface Calificable {

    void calificar(int puntaje);
}

package Exceptions;

public class PlantaRepetidaException extends RuntimeException{
    
    private static final String MESSAGE = "Ya tenes esta planta en tu jardin";
    
    public PlantaRepetidaException() {
        this(MESSAGE);
    }

    public PlantaRepetidaException(String MESSAGE) {
        super(MESSAGE);
    }
}

package model;

import java.util.Comparator;
import repository.CSVSerializable;

public class Cancion implements Comparable<Cancion>, Comparator<Cancion>, CSVSerializable{
    
    private int id;
    private String titulo;
    private String artista;
    private GeneroMusical genero;

    public Cancion(int id, String titulo, String artista, GeneroMusical genero) {
        this.id = id;
        this.titulo = titulo;
        this.artista = artista;
        this.genero = genero;
    }

    @Override
    public String toString() {
        return "Cancion{" + "id=" + id + ", titulo=" + titulo + ", artista=" + artista + ", genero=" + genero + '}';
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getArtista() {
        return artista;
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    @Override
    public int compareTo(Cancion c) {
        return Integer.compare(id, c.getId());
    }
    
    @Override
    public int compare(Cancion c1, Cancion c2) {
        return c1.compareTo(c2);
    }

    @Override
    public String toCSV() {
        return id + "," + titulo + "," + artista + "," + genero; 
    }
    
    public static Cancion fromCSV(String cancionCSV){
        Cancion nuevaCancion = null;
        
        if(cancionCSV.endsWith("\n")){
            cancionCSV = cancionCSV.substring(0, cancionCSV.length() -1);
        }
        
        String[] values = cancionCSV.split(",");
        if(values.length == 4){
            int id = Integer.parseInt(values[0]);
            String titulo = values[1];
            String artista = values[2];
            GeneroMusical genero = GeneroMusical.valueOf(values[3]);
            nuevaCancion = new Cancion(id, titulo, artista, genero);
        }
        return nuevaCancion;
    }
}